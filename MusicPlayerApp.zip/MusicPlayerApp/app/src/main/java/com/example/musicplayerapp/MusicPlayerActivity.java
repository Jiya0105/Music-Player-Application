package com.example.musicplayerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class MusicPlayerActivity extends AppCompatActivity {

    TextView titleTv,currentTimeTv,totalTimeTv;
    SeekBar seekBar;
    ImageView pausePlay,nextBtn,previousBtn,musicIcon;

    ArrayList<AudioModel> songsList;
    AudioModel currentSong;

    MediaPlayer mediaPlayer = MyMediaPlayer.getInstance();

    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_player);

        titleTv = findViewById(R.id.song_title);
        currentTimeTv = findViewById(R.id.current_time);
        totalTimeTv = findViewById(R.id.total_time);
        seekBar = findViewById(R.id.seek_bar);
        pausePlay = findViewById(R.id.pause_play);
        nextBtn = findViewById(R.id.next);
        previousBtn = findViewById(R.id.previous);
        musicIcon = findViewById(R.id.music__icon);

        titleTv.setSelected(true);

        songsList = (ArrayList<AudioModel>) getIntent().getSerializableExtra("LIST");

        setResourcesWithMusic();

        // 🔁 Update UI continuously
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(mediaPlayer!=null){

                    seekBar.setProgress(mediaPlayer.getCurrentPosition());
                    currentTimeTv.setText(convertToMMSS(mediaPlayer.getCurrentPosition()+""));

                    if(mediaPlayer.isPlaying()){
                        pausePlay.setImageResource(R.drawable.baseline_pause_circle_outline_24);
                    }else{
                        pausePlay.setImageResource(R.drawable.baseline_play_circle_outline_24);
                    }
                }
                handler.postDelayed(this,100);
            }
        });

        // 🎧 Seekbar control
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(mediaPlayer!=null && fromUser){
                    mediaPlayer.seekTo(progress);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    void setResourcesWithMusic(){
        currentSong = songsList.get(MyMediaPlayer.currentIndex);

        titleTv.setText(currentSong.getTitle());
        totalTimeTv.setText(convertToMMSS(currentSong.getDuration()));

        // 🎬 Button animations
        Animation clickAnim = AnimationUtils.loadAnimation(this, R.anim.button_click);

        pausePlay.setOnClickListener(v -> {
            v.startAnimation(clickAnim);
            pausePlay();
        });

        nextBtn.setOnClickListener(v -> {
            v.startAnimation(clickAnim);
            playNextSong();
        });

        previousBtn.setOnClickListener(v -> {
            v.startAnimation(clickAnim);
            playPreviousSong();
        });

        playMusic();
    }

    private void playMusic(){
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(currentSong.getPath());
            mediaPlayer.prepare();
            mediaPlayer.start();

            seekBar.setProgress(0);
            seekBar.setMax(mediaPlayer.getDuration());

            // 🔥 Start smooth rotation
            rotateIcon();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 🔁 Smooth infinite rotation
    void rotateIcon(){
        musicIcon.animate()
                .rotationBy(360f)
                .setDuration(8000)
                .setInterpolator(new LinearInterpolator())
                .withEndAction(this::rotateIcon)
                .start();
    }

    private void playNextSong(){
        if(MyMediaPlayer.currentIndex == songsList.size()-1) return;

        MyMediaPlayer.currentIndex++;
        setResourcesWithMusic();
    }

    private void playPreviousSong(){
        if(MyMediaPlayer.currentIndex == 0) return;

        MyMediaPlayer.currentIndex--;
        setResourcesWithMusic();
    }

    private void pausePlay(){
        if(mediaPlayer.isPlaying()){
            mediaPlayer.pause();
        }else{
            mediaPlayer.start();
            rotateIcon(); // resume rotation
        }
    }


    public static String convertToMMSS(String duration){
        Long millis = Long.parseLong(duration);
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millis) % 60,
                TimeUnit.MILLISECONDS.toSeconds(millis) % 60);
    }
}